﻿DELETE FROM 姓名_期中考成績 WHERE 姓名=N'不存在的人';
SELECT * FROM 學號_宿舍 WHERE 學號 = 'F12345678';
SELECT * FROM 姓名_學號_系級 WHERE 姓名 = N'不存在的人';
SELECT * FROM 姓名_期中考成績 WHERE 姓名 = N'不存在的人';