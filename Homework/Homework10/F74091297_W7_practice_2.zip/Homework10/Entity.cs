﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;
namespace Homework10
{
    class Entity
    {
        public Button EntityButton;
        public Color EntityButtonColor;
        public String EntityButtonText;
        public int Y;
        public int X;
        public int Type;
        public bool isDead;
        public int speed;
    }
}
